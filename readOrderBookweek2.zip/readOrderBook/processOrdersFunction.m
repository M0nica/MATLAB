function [ output_args ] = processOrdersFunction( bids, asks )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
%--this stuff should go in original file
%-it should output a figure with printbook 

%--this function will be called in the original file

orderbook(1:12,1:2) = bids 
orderbook(1:12,3:4) = asks
clf


end

